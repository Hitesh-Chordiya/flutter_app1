import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_app/pages/homepage.dart';
import 'package:flutter_app/pages/login_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/user.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  final FirebaseAuth _auth=FirebaseAuth.instance;
  dynamic user;
  dynamic x;
  void inputData() async {
     user= await _auth.currentUser();
    if(user==null)
        x=LoginPage();
    else
      x=HomePage();
    // here you write the codes to input the data into firestore
  }
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    inputData();
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: LoginPage(),
    );

  }
}
